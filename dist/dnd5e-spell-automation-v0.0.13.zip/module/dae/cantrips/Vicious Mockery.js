export default {
	"_id": "0kd6h8qmvb4bopan",
	"changes": [
		{
			"key": "flags.midi-qol.disadvantage.attack.all",
			"mode": 0,
			"value": "1",
			"priority": "20"
		},
		{
			"key": "macro.execute",
			"value": "\"Compendium.dnd5e-spell-automation.Macros.Vicious Mockery AE\"",
			"mode": 0,
			"priority": "20"
		}
	],
	"disabled": false,
	"duration": {
		"rounds": 1,
		"startTime": null
	},
	"icon": "icons/creatures/magical/spirit-poison-smoke-green.webp",
	"label": "Vicious Mockery",
	"origin": "Actor.57AEBDVVsTuaHOZn.Item.1ZJdvN1vLR1PJOWa",
	"tint": "",
	"transfer": false,
	"flags": {
		"dae": {
			"selfTarget": false,
			"stackable": "none",
			"durationExpression": "",
			"macroRepeat": "none",
			"specialDuration": [],
			"transfer": false
		},
		"core": {
			"statusId": ""
		}
	}
};