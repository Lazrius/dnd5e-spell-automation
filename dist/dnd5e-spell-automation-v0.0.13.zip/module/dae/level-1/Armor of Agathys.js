export default {
	"_id": "i364wcrhgsl398xw",
	"changes": [
		{
			"key": "macro.execute",
			"mode": 0,
			"value": "\"Compendium.dnd5e-spell-automation.Macros.Armor of Agathys AE\"",
			"priority": "20"
		}
	],
	"disabled": false,
	"duration": {
		"seconds": 3600,
		"startTime": null
	},
	"icon": "icons/magic/water/heart-ice-freeze.webp",
	"label": "Armor of Agathys",
	"tint": null,
	"transfer": false,
	"flags": {
		"dae": {
			"selfTarget": true,
			"stackable": "none",
			"durationExpression": "",
			"macroRepeat": "none",
			"specialDuration": [],
			"transfer": false
		},
		"core": {
			"statusId": ""
		}
	}
};