export default {
	"_id": "q3966d2scbhzrv5k",
	"changes": [],
	"disabled": false,
	"duration": {
		"seconds": 60,
		"startTime": null
	},
	"icon": "icons/magic/holy/barrier-shield-winged-blue.webp",
	"label": "Sanctuary",
	"origin": "Actor.57AEBDVVsTuaHOZn.Item.4hp8PhnkkgPTrZo4",
	"transfer": false,
	"flags": {}
};