export default {
	"_id": "u3e8xfern9dyiwkq",
	"changes": [
		{
			"key": "flags.midi-qol.DR.heal",
			"mode": 5,
			"value": "100",
			"priority": "20"
		}
	],
	"disabled": false,
	"duration": {
		"rounds": 1,
		"startTime": null
	},
	"icon": "icons/magic/lightning/claws-unarmed-strike-teal.webp",
	"label": "Chill Touch",
	"origin": "Actor.57AEBDVVsTuaHOZn.Item.L2zn5RU1K5kb2rKu",
	"tint": "",
	"transfer": false,
	"flags": {
		"dae": {
			"selfTarget": false,
			"stackable": "none",
			"durationExpression": "",
			"macroRepeat": "none",
			"specialDuration": [],
			"transfer": false
		},
		"core": {
			"statusId": ""
		}
	}
};