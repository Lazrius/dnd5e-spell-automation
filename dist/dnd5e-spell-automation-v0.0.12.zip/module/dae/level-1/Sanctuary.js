export default {
	"_id": "q3966d2scbhzrv5k",
	"changes": [
		{
			"key": "macro.execute",
			"value": "\"Compendium.dnd5e-spell-automation.Macros.Sanctuary AE\"",
			"mode": 0,
			"priority": "20"
		}
	],
	"disabled": false,
	"duration": {
		"seconds": 60,
		"startTime": null
	},
	"icon": "icons/magic/holy/barrier-shield-winged-blue.webp",
	"label": "Sanctuary",
	"origin": "Actor.57AEBDVVsTuaHOZn.Item.4hp8PhnkkgPTrZo4",
	"transfer": false,
	"flags": {}
};