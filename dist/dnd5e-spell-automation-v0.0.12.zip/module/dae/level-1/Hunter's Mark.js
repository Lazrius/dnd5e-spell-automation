export default {
	"_id": "1bdkt6vzb17e9sxl",
	"changes": [
		{
			"key": "macro.execute",
			"value": "\"Compendium.dnd5e-spell-automation.Macros.Hunter's Mark AE\"",
			"mode": 0,
			"priority": "20"
		}
	],
	"disabled": false,
	"duration": {
		"seconds": 3600,
		"startTime": null
	},
	"icon": "icons/skills/ranged/target-bullseye-arrow-green.webp",
	"label": "Hunter's Mark",
	"origin": "Actor.57AEBDVVsTuaHOZn.Item.S2oNE8qRVSH6JNrx",
	"transfer": false,
	"flags": {}
};