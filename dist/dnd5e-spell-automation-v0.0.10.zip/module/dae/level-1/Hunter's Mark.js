export default {
	"_id": "1bdkt6vzb17e9sxl",
	"changes": [],
	"disabled": false,
	"duration": {
		"seconds": 3600,
		"startTime": null
	},
	"icon": "icons/skills/ranged/target-bullseye-arrow-green.webp",
	"label": "Hunter's Mark",
	"origin": "Actor.57AEBDVVsTuaHOZn.Item.S2oNE8qRVSH6JNrx",
	"transfer": false,
	"flags": {}
};