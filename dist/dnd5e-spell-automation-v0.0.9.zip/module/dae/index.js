import cantrips from './cantrips/_index.js';
import level1 from './level-1/_index.js';

export default {
	...cantrips,
	...level1
};