export default {
	"_id": "7ltd5a8fe0ej70af",
	"changes": [
		{
			"key": "data.bonuses.abilities.save",
			"mode": 2,
			"value": "-1d4",
			"priority": "20"
		}
	],
	"disabled": false,
	"duration": {
		"rounds": 1,
		"startTime": null
	},
	"icon": "icons/magic/air/wind-vortex-swirl-purple.webp",
	"label": "Mind Sliver",
	"origin": "Actor.57AEBDVVsTuaHOZn.Item.hgKn985o8zs8A19I",
	"tint": "",
	"transfer": false,
	"flags": {
		"dae": {
			"selfTarget": false,
			"stackable": "none",
			"durationExpression": "",
			"macroRepeat": "none",
			"specialDuration": [],
			"transfer": false
		},
		"core": {
			"statusId": ""
		}
	}
};