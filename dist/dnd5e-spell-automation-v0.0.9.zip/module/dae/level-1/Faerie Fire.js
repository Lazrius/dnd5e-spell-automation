export default {
	"_id": "4m5n989szn32mvs0",
	"changes": [],
	"disabled": false,
	"duration": {
		"seconds": 60,
		"startTime": null
	},
	"icon": "icons/magic/light/explosion-star-glow-silhouette.webp",
	"label": "Faerie Fire",
	"origin": "Actor.57AEBDVVsTuaHOZn.Item.sSqJz8SUaeAK6k0Z",
	"tint": "",
	"transfer": false,
	"flags": {
		"dae": {
			"selfTarget": false,
			"stackable": "none",
			"durationExpression": "",
			"macroRepeat": "none",
			"specialDuration": [],
			"transfer": false
		},
		"core": {
			"statusId": ""
		}
	}
};