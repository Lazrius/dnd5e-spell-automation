export default {
	"_id": "jjkle4yd9vjjqnsz",
	"changes": [],
	"disabled": false,
	"duration": {
		"seconds": 3600,
		"startTime": null
	},
	"icon": "icons/magic/control/voodoo-doll-pain-damage-red.webp",
	"label": "Hex",
	"origin": "Actor.57AEBDVVsTuaHOZn.Item.u1UwvyJayZqkYmHa",
	"transfer": false,
	"flags": {}
};