export default {
	"_id": "eogwcdvwy4r0vx77",
	"changes": [
		{
			"key": "macro.execute",
			"value": "\"Compendium.dnd5e-spell-automation.Macros.Light AE\"",
			"mode": 0,
			"priority": "20"
		}
	],
	"disabled": false,
	"duration": {
		"seconds": 3600,
		"startTime": null
	},
	"icon": "icons/magic/light/orb-lightbulb-gray.webp",
	"label": "Light",
	"origin": "Actor.57AEBDVVsTuaHOZn.Item.RTuv1NowZXm03NMg",
	"tint": "",
	"transfer": false,
	"flags": {
		"dae": {
			"selfTarget": false,
			"stackable": "none",
			"durationExpression": "",
			"macroRepeat": "none",
			"specialDuration": [],
			"transfer": false
		},
		"core": {
			"statusId": ""
		}
	}
};